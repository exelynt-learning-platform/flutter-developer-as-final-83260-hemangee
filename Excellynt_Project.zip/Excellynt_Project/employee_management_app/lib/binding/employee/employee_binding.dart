// lib/binding/employee/employee_binding.dart
import 'package:get/get.dart';
import '../../controller/employee/employee_controller.dart';

class EmployeeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<EmployeeController>(() => EmployeeController());
  }
}
