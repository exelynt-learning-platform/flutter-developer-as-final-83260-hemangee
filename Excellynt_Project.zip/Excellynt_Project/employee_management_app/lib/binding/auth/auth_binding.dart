// lib/binding/auth/auth_binding.dart
import 'package:get/get.dart';
import '../../controller/auth/auth_controller.dart';

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(() => AuthController());
  }
}
