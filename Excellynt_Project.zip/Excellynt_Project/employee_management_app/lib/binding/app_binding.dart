// lib/binding/app_binding.dart
import 'package:get/get.dart';
import '../api/api_client.dart';
import '../controller/app_controller.dart';
import '../controller/auth/auth_controller.dart';

class AppBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<ApiClient>(ApiClient(), permanent: true);
    Get.put<AppController>(AppController(), permanent: true);
    Get.put<AuthController>(AuthController(), permanent: true);
  }
}
