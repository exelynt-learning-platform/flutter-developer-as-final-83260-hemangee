// lib/main.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sizer/sizer.dart';
import 'binding/app_binding.dart';
import 'controller/app_controller.dart';
import 'routes/app_pages.dart';
import 'routes/routes.dart';
import 'utils/config.dart';
import 'utils/theme_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize GetStorage local persistence
  await GetStorage.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
        return GetBuilder<AppController>(
          init: AppController(),
          builder: (appController) {
            return Obx(
              () => GetMaterialApp(
                title: Config.appName,
                debugShowCheckedModeBanner: false,
                theme: ThemeConfig.lightTheme(),
                darkTheme: ThemeConfig.darkTheme(),
                themeMode: appController.isDarkMode.value
                    ? ThemeMode.dark
                    : ThemeMode.light,
                initialBinding: AppBinding(),
                initialRoute: Routes.splash,
                getPages: AppPages.pages,
              ),
            );
          },
        );
      },
    );
  }
}
