// lib/routes/app_pages.dart
import 'package:get/get.dart';
import '../binding/auth/auth_binding.dart';
import '../binding/employee/employee_binding.dart';
import '../screens/Auth/forgot_password_screen.dart';
import '../screens/Auth/login_screen.dart';
import '../screens/Auth/register_screen.dart';
import '../screens/Employee/employee_dashboard_screen.dart';
import '../screens/Employee/employee_detail_screen.dart';
import '../screens/Employee/employee_form_screen.dart';
import '../screens/Splash/splash_screen.dart';
import 'routes.dart';

class AppPages {
  AppPages._();

  static const Transition transition = Transition.cupertino;
  static const String initialRoute = Routes.splash;

  static final List<GetPage> pages = [
    GetPage(
      name: Routes.splash,
      page: () => const SplashScreen(),
      transition: transition,
    ),
    GetPage(
      name: Routes.login,
      page: () => const LoginScreen(),
      binding: AuthBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.register,
      page: () => const RegisterScreen(),
      binding: AuthBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.forgotPassword,
      page: () => const ForgotPasswordScreen(),
      binding: AuthBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.employeeList,
      page: () => const EmployeeDashboardScreen(),
      binding: EmployeeBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.employeeDetail,
      page: () => const EmployeeDetailScreen(),
      binding: EmployeeBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.addEmployee,
      page: () => const EmployeeFormScreen(isEdit: false),
      binding: EmployeeBinding(),
      transition: transition,
    ),
    GetPage(
      name: Routes.editEmployee,
      page: () => const EmployeeFormScreen(isEdit: true),
      binding: EmployeeBinding(),
      transition: transition,
    ),
  ];
}
