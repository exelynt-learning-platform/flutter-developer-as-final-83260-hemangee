// lib/routes/routes.dart
class Routes {
  Routes._();

  static const String splash = '/splash';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String employeeList = '/employee-list';
  static const String employeeDashboard = '/employee-list';
  static const String employeeDetail = '/employee-detail';
  static const String addEmployee = '/add-employee';
  static const String employeeAdd = '/add-employee';
  static const String editEmployee = '/edit-employee';
  static const String employeeEdit = '/edit-employee';
}
