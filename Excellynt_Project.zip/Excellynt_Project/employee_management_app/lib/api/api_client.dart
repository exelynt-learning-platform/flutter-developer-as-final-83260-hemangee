// lib/api/api_client.dart
import 'dart:async';
import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../utils/config.dart';
import '../utils/connection.dart';
import 'api_exception.dart';

class ApiClient {
  static ApiClient _instance = ApiClient._internal();
  static ApiClient get instance => _instance;

  final Connection _connection = Connection();
  static CancelToken _cancelToken = CancelToken();

  late final Dio _dio;

  ApiClient() {
    _dio = Dio(
      BaseOptions(
        baseUrl: Config.baseUrl,
        connectTimeout: Duration(seconds: Config.connectTimeout),
        receiveTimeout: Duration(seconds: Config.receiveTimeout),
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
      ),
    );
  }

  ApiClient._internal() {
    _dio = Dio(
      BaseOptions(
        baseUrl: Config.baseUrl,
        connectTimeout: Duration(seconds: Config.connectTimeout),
        receiveTimeout: Duration(seconds: Config.receiveTimeout),
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          if (kDebugMode) log('→ [${options.method}] ${options.uri}');
          return handler.next(options);
        },
        onResponse: (response, handler) {
          if (kDebugMode) log('← [${response.statusCode}] ${response.requestOptions.uri}');
          return handler.next(response);
        },
        onError: (DioException e, handler) {
          if (kDebugMode) log('✗ API Error: ${e.message}');
          return handler.next(e);
        },
      ),
    );
  }

  static void init() {
    _instance = ApiClient._internal();
  }

  static void cancelRequests() {
    _cancelToken.cancel();
    _cancelToken = CancelToken();
  }

  // ─── GET ────────────────────────────────────────────────────────────────────
  Future<dynamic> getAPICall({
    required String url,
    Map<String, dynamic>? queryParameters,
    int timeOut = 30,
  }) async {
    if (!await Connection.checkInternet()) throw const NoInternetException();
    try {
      final res = await _dio
          .get(url, queryParameters: queryParameters, cancelToken: _cancelToken)
          .timeout(Duration(seconds: timeOut), onTimeout: () => throw const TimeoutException());
      return _handleResponse(res);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // ─── POST ───────────────────────────────────────────────────────────────────
  Future<dynamic> postAPICall({
    required String url,
    dynamic data,
    Map<String, dynamic>? queryParameters,
    int timeOut = 30,
  }) async {
    if (!await Connection.checkInternet()) throw const NoInternetException();
    try {
      final res = await _dio
          .post(url, data: data, queryParameters: queryParameters, cancelToken: _cancelToken)
          .timeout(Duration(seconds: timeOut), onTimeout: () => throw const TimeoutException());
      return _handleResponse(res);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // ─── PUT ────────────────────────────────────────────────────────────────────
  Future<dynamic> putAPICall({
    required String url,
    dynamic data,
    Map<String, dynamic>? queryParameters,
    int timeOut = 30,
  }) async {
    if (!await Connection.checkInternet()) throw const NoInternetException();
    try {
      final res = await _dio
          .put(url, data: data, queryParameters: queryParameters, cancelToken: _cancelToken)
          .timeout(Duration(seconds: timeOut), onTimeout: () => throw const TimeoutException());
      return _handleResponse(res);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // ─── DELETE ─────────────────────────────────────────────────────────────────
  Future<dynamic> deleteAPICall({
    required String url,
    Map<String, dynamic>? queryParameters,
    int timeOut = 30,
  }) async {
    if (!await Connection.checkInternet()) throw const NoInternetException();
    try {
      final res = await _dio
          .delete(url, queryParameters: queryParameters, cancelToken: _cancelToken)
          .timeout(Duration(seconds: timeOut), onTimeout: () => throw const TimeoutException());
      return _handleResponse(res);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────
  dynamic _handleResponse(Response res) {
    if (res.statusCode != null && res.statusCode! >= 200 && res.statusCode! < 300) {
      return res.data;
    }
    throw ApiException(
      res.data?['message']?.toString() ?? 'Server error',
      statusCode: res.statusCode,
    );
  }

  ApiException _handleDioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return const ApiException('Request timed out. Please try again.');
      case DioExceptionType.connectionError:
        return const ApiException('No internet connection.');
      default:
        final code = e.response?.statusCode;
        final msg = e.response?.data?['message']?.toString() ?? e.message ?? 'Unknown error';
        return ApiException(msg, statusCode: code);
    }
  }
}
