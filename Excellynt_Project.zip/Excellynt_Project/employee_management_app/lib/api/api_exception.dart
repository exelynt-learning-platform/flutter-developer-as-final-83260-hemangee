// lib/api/api_exception.dart
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  const ApiException(this.message, {this.statusCode});

  @override
  String toString() => 'ApiException($statusCode): $message';
}

class TimeoutException implements Exception {
  final String message;
  const TimeoutException({this.message = 'Request timed out'});
}

class NoInternetException implements Exception {
  final String message;
  const NoInternetException({this.message = 'No internet connection'});
}
