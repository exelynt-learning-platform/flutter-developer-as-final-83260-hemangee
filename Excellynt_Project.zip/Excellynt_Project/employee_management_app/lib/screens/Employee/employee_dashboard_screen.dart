// lib/screens/Employee/employee_dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../controller/app_controller.dart';
import '../../controller/auth/auth_controller.dart';
import '../../controller/employee/employee_controller.dart';
import '../../controller/employee/employee_model.dart';
import '../../routes/routes.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';
import '../../widgets/dialogs/confirm_dialog.dart';

class EmployeeDashboardScreen extends GetView<EmployeeController> {
  const EmployeeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authController = Get.find<AuthController>();
    final appController = Get.find<AppController>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Employee Portal',
          style: TextHelper.h2(context).copyWith(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: Obx(
              () => Icon(
                appController.isDarkMode.value
                    ? Icons.light_mode_outlined
                    : Icons.dark_mode_outlined,
              ),
            ),
            onPressed: appController.toggleTheme,
            tooltip: 'Toggle Theme',
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => controller.fetchEmployees(showLoading: true),
            tooltip: 'Refresh List',
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: const BoxDecoration(color: AppColors.primary),
              accountName: Obx(
                () => Text(
                  authController.userName.value,
                  style: TextHelper.h3(context).copyWith(color: Colors.white),
                ),
              ),
              accountEmail: Obx(
                () => Text(
                  authController.userEmail.value,
                  style: TextHelper.bodyMedium(context)
                      .copyWith(color: Colors.white70),
                ),
              ),
              currentAccountPicture: Obx(
                () => CircleAvatar(
                  backgroundColor: Colors.white,
                  backgroundImage: authController.userPhoto.value.isNotEmpty
                      ? NetworkImage(authController.userPhoto.value)
                      : null,
                  child: authController.userPhoto.value.isEmpty
                      ? Text(
                          authController.userName.value.isNotEmpty
                              ? authController.userName.value[0].toUpperCase()
                              : 'U',
                          style: TextHelper.h1(context)
                              .copyWith(color: AppColors.primary),
                        )
                      : null,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const Text('Dashboard'),
              selected: true,
              onTap: () => Get.back(),
            ),
            ListTile(
              leading: const Icon(Icons.person_add_outlined),
              title: const Text('Add Employee'),
              onTap: () {
                Get.back();
                controller.clearForm();
                Get.toNamed(Routes.employeeAdd);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout_rounded, color: AppColors.error),
              title: Text(
                'Logout',
                style: TextHelper.bodyMedium(context)
                    .copyWith(color: AppColors.error),
              ),
              onTap: () {
                Get.back();
                ConfirmDialog.show(
                  title: 'Logout',
                  message: 'Are you sure you want to log out?',
                  confirmText: 'Logout',
                  onConfirm: authController.logout,
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        onPressed: () {
          controller.clearForm();
          Get.toNamed(Routes.employeeAdd);
        },
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'Add Employee',
          style: TextHelper.buttonText(context).copyWith(color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          // Search and Filter Bar
          Container(
            padding: EdgeInsets.all(4.w),
            color: Theme.of(context).cardColor,
            child: Column(
              children: [
                // Search Input
                TextField(
                  onChanged: (val) => controller.searchQuery.value = val,
                  decoration: InputDecoration(
                    hintText: 'Search by ID or Name...',
                    prefixIcon: const Icon(Icons.search, color: AppColors.primary),
                    suffixIcon: Obx(
                      () => controller.searchQuery.value.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () => controller.searchQuery.value = '',
                            )
                          : const SizedBox.shrink(),
                    ),
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 4.w,
                      vertical: 1.5.h,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.borderLight),
                    ),
                  ),
                ),
                SizedBox(height: 1.5.h),
                // Filter dropdown + view mode toggle
                Row(
                  children: [
                    Text(
                      'Filter by: ',
                      style: TextHelper.captionMedium(context).copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Obx(
                        () => Container(
                          padding: EdgeInsets.symmetric(horizontal: 3.w),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.borderLight),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: controller.selectedFilterField.value,
                              isExpanded: true,
                              items: const [
                                DropdownMenuItem(
                                    value: 'Name', child: Text('Name')),
                                DropdownMenuItem(
                                    value: 'Email', child: Text('Email')),
                                DropdownMenuItem(
                                    value: 'Mobile', child: Text('Mobile')),
                                DropdownMenuItem(
                                    value: 'Country', child: Text('Country')),
                              ],
                              onChanged: (val) {
                                if (val != null) {
                                  controller.selectedFilterField.value = val;
                                }
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    IconButton(
                      icon: Obx(
                        () => Icon(
                          controller.isGridView.value
                              ? Icons.view_list_rounded
                              : Icons.grid_view_rounded,
                          color: AppColors.primary,
                        ),
                      ),
                      onPressed: controller.toggleViewMode,
                      tooltip: 'Toggle View Mode',
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Count Header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Obx(
                  () => Text(
                    'Total: ${controller.filteredEmployees.length} employees',
                    style: TextHelper.captionMedium(context).copyWith(
                      color: AppColors.textSecondaryLight,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Obx(
                  () => controller.isOffline.value
                      ? Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 0.4.h),
                          decoration: BoxDecoration(
                            color: Colors.orange.shade100,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            'Offline Mode',
                            style: TextHelper.captionSmall(context).copyWith(
                              color: Colors.orange.shade900,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),

          // Employee List / Grid
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.filteredEmployees.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.people_outline,
                        size: 40.sp,
                        color: AppColors.textSecondaryLight,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'No employees found',
                        style: TextHelper.h3(context),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'Try adjusting your search or add a new employee',
                        style: TextHelper.captionMedium(context),
                      ),
                    ],
                  ),
                );
              }

              if (controller.isGridView.value) {
                return GridView.builder(
                  padding: EdgeInsets.all(3.w),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: Get.width > 600 ? 3 : 2,
                    childAspectRatio: 0.85,
                    crossAxisSpacing: 3.w,
                    mainAxisSpacing: 3.w,
                  ),
                  itemCount: controller.filteredEmployees.length,
                  itemBuilder: (context, index) {
                    final emp = controller.filteredEmployees[index];
                    return _EmployeeGridCard(employee: emp);
                  },
                );
              }

              return ListView.separated(
                padding: EdgeInsets.all(3.w),
                itemCount: controller.filteredEmployees.length,
                separatorBuilder: (context, index) => SizedBox(height: 1.5.h),
                itemBuilder: (context, index) {
                  final emp = controller.filteredEmployees[index];
                  return _EmployeeListCard(employee: emp);
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _EmployeeListCard extends StatelessWidget {
  final EmployeeModel employee;

  const _EmployeeListCard({required this.employee});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<EmployeeController>();

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        leading: CircleAvatar(
          radius: 24,
          backgroundColor: AppColors.primaryLight,
          backgroundImage: employee.avatar != null && employee.avatar!.isNotEmpty
              ? NetworkImage(employee.avatar!)
              : null,
          child: employee.avatar == null || employee.avatar!.isEmpty
              ? Text(
                  employee.name.isNotEmpty ? employee.name[0].toUpperCase() : 'E',
                  style: TextHelper.h3(context).copyWith(color: AppColors.primary),
                )
              : null,
        ),
        title: Text(
          employee.name,
          style: TextHelper.h3(context),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 0.5.h),
            Row(
              children: [
                const Icon(Icons.email_outlined, size: 14, color: AppColors.textSecondaryLight),
                SizedBox(width: 1.w),
                Expanded(
                  child: Text(
                    employee.email,
                    style: TextHelper.captionMedium(context),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            SizedBox(height: 0.3.h),
            Row(
              children: [
                const Icon(Icons.phone_outlined, size: 14, color: AppColors.textSecondaryLight),
                SizedBox(width: 1.w),
                Text(
                  employee.mobile,
                  style: TextHelper.captionMedium(context),
                ),
                const Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.2.h),
                  decoration: BoxDecoration(
                    color: AppColors.accentLight.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    employee.country,
                    style: TextHelper.captionSmall(context).copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        onTap: () {
          Get.toNamed(Routes.employeeDetail, arguments: employee);
        },
        trailing: PopupMenuButton<String>(
          onSelected: (val) {
            if (val == 'edit') {
              controller.loadEmployeeForEdit(employee);
              Get.toNamed(Routes.employeeEdit, arguments: employee);
            } else if (val == 'delete') {
              ConfirmDialog.show(
                title: 'Delete Employee',
                message: 'Are you sure you want to delete ${employee.name}?',
                confirmText: 'Delete',
                confirmColor: AppColors.error,
                onConfirm: () => controller.deleteEmployee(employee.id),
              );
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'edit',
              child: Row(
                children: [
                  Icon(Icons.edit_outlined, color: AppColors.primary, size: 18),
                  SizedBox(width: 8),
                  Text('Edit'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  Icon(Icons.delete_outline, color: AppColors.error, size: 18),
                  SizedBox(width: 8),
                  Text('Delete'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmployeeGridCard extends StatelessWidget {
  final EmployeeModel employee;

  const _EmployeeGridCard({required this.employee});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<EmployeeController>();

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Get.toNamed(Routes.employeeDetail, arguments: employee);
        },
        child: Padding(
          padding: EdgeInsets.all(3.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: AppColors.primaryLight,
                backgroundImage:
                    employee.avatar != null && employee.avatar!.isNotEmpty
                        ? NetworkImage(employee.avatar!)
                        : null,
                child: employee.avatar == null || employee.avatar!.isEmpty
                    ? Text(
                        employee.name.isNotEmpty
                            ? employee.name[0].toUpperCase()
                            : 'E',
                        style: TextHelper.h2(context)
                            .copyWith(color: AppColors.primary),
                      )
                    : null,
              ),
              SizedBox(height: 1.h),
              Text(
                employee.name,
                style: TextHelper.h3(context),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 0.5.h),
              Text(
                employee.email,
                style: TextHelper.captionSmall(context),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 1.h),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.3.h),
                decoration: BoxDecoration(
                  color: AppColors.accentLight.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  employee.country,
                  style: TextHelper.captionSmall(context).copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined,
                        color: AppColors.primary, size: 18),
                    onPressed: () {
                      controller.loadEmployeeForEdit(employee);
                      Get.toNamed(Routes.employeeEdit, arguments: employee);
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: AppColors.error, size: 18),
                    onPressed: () {
                      ConfirmDialog.show(
                        title: 'Delete Employee',
                        message:
                            'Are you sure you want to delete ${employee.name}?',
                        confirmText: 'Delete',
                        confirmColor: AppColors.error,
                        onConfirm: () => controller.deleteEmployee(employee.id),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
