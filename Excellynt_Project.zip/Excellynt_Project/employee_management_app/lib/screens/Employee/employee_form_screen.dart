// lib/screens/Employee/employee_form_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../controller/employee/employee_controller.dart';
import '../../controller/employee/employee_model.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';
import '../../utils/validators.dart';
import '../../widgets/textfields/custom_textfield.dart';

class EmployeeFormScreen extends GetView<EmployeeController> {
  final bool isEdit;

  const EmployeeFormScreen({super.key, this.isEdit = false});

  @override
  Widget build(BuildContext context) {
    final EmployeeModel? emp = isEdit ? Get.arguments as EmployeeModel? : null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Employee' : 'Add New Employee'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
          child: Form(
            key: controller.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                CustomTextField(
                  controller: controller.nameController,
                  label: 'Full Name',
                  hint: 'enter full name',
                  prefixIcon: Icons.person_outline,
                  validator: (v) => Validators.required(v, field: 'Full Name'),
                ),
                CustomTextField(
                  controller: controller.emailController,
                  label: 'Email Address',
                  hint: 'enter email address',
                  prefixIcon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                  validator: Validators.email,
                ),
                CustomTextField(
                  controller: controller.mobileController,
                  label: 'Mobile Number',
                  hint: 'enter 10-digit mobile number',
                  prefixIcon: Icons.phone_outlined,
                  keyboardType: TextInputType.phone,
                  validator: Validators.phone,
                ),

                // Cascading Location Dropdowns
                Text(
                  'Country',
                  style: TextHelper.captionMedium(context).copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 0.8.h),
                Obx(
                  () => Container(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.borderLight),
                      borderRadius: BorderRadius.circular(12),
                      color: Theme.of(context).cardColor,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        hint: const Text('Select Country'),
                        value: (controller.selectedCountry.value ?? '').isEmpty
                            ? null
                            : controller.selectedCountry.value,
                        items: controller.countriesList
                            .map((c) => DropdownMenuItem(
                                  value: c.country,
                                  child: Text(c.country),
                                ))
                            .toList(),
                        onChanged: (val) {
                          if (val != null) controller.onCountryChanged(val);
                        },
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h),

                Text(
                  'State',
                  style: TextHelper.captionMedium(context).copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 0.8.h),
                Obx(
                  () => Container(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.borderLight),
                      borderRadius: BorderRadius.circular(12),
                      color: Theme.of(context).cardColor,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        hint: const Text('Select State'),
                        value: (controller.selectedState.value ?? '').isEmpty
                            ? null
                            : controller.selectedState.value,
                        items: controller.statesList
                            .map((s) => DropdownMenuItem(
                                  value: s,
                                  child: Text(s),
                                ))
                            .toList(),
                        onChanged: (controller.selectedCountry.value ?? '').isEmpty
                            ? null
                            : (val) {
                                if (val != null) controller.onStateChanged(val);
                              },
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h),

                Text(
                  'District',
                  style: TextHelper.captionMedium(context).copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 0.8.h),
                Obx(
                  () => Container(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.borderLight),
                      borderRadius: BorderRadius.circular(12),
                      color: Theme.of(context).cardColor,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        hint: const Text('Select District'),
                        value: (controller.selectedDistrict.value ?? '').isEmpty
                            ? null
                            : controller.selectedDistrict.value,
                        items: controller.districtsList
                            .map((d) => DropdownMenuItem(
                                  value: d,
                                  child: Text(d),
                                ))
                            .toList(),
                        onChanged: (controller.selectedState.value ?? '').isEmpty
                            ? null
                            : (val) {
                                if (val != null) controller.selectedDistrict.value = val;
                              },
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 4.h),

                Obx(
                  () => ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: controller.isLoading.value
                        ? null
                        : () {
                            if (isEdit && emp != null) {
                              controller.updateEmployee(emp.id);
                            } else {
                              controller.createEmployee();
                            }
                          },
                    child: controller.isLoading.value
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : Text(
                            isEdit ? 'Update Employee' : 'Save Employee',
                            style: TextHelper.buttonText(context).copyWith(
                              color: Colors.white,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
