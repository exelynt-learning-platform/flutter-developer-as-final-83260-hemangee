// lib/screens/Employee/employee_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../controller/employee/employee_controller.dart';
import '../../controller/employee/employee_model.dart';
import '../../routes/routes.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';
import '../../widgets/dialogs/confirm_dialog.dart';

class EmployeeDetailScreen extends StatelessWidget {
  const EmployeeDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final EmployeeModel emp = Get.arguments as EmployeeModel;
    final controller = Get.find<EmployeeController>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {
              controller.loadEmployeeForEdit(emp);
              Get.toNamed(Routes.employeeEdit, arguments: emp);
            },
            tooltip: 'Edit Employee',
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.error),
            onPressed: () {
              ConfirmDialog.show(
                title: 'Delete Employee',
                message: 'Are you sure you want to delete ${emp.name}?',
                confirmText: 'Delete',
                confirmColor: AppColors.error,
                onConfirm: () {
                  controller.deleteEmployee(emp.id);
                  Get.back();
                },
              );
            },
            tooltip: 'Delete Employee',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(5.w),
        child: Column(
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 45.sp,
                    backgroundColor: AppColors.primaryLight,
                    backgroundImage: emp.avatar != null && emp.avatar!.isNotEmpty
                        ? NetworkImage(emp.avatar!)
                        : null,
                    child: emp.avatar == null || emp.avatar!.isEmpty
                        ? Text(
                            emp.name.isNotEmpty ? emp.name[0].toUpperCase() : 'E',
                            style: TextHelper.h1(context).copyWith(
                              color: AppColors.primary,
                              fontSize: 30.sp,
                            ),
                          )
                        : null,
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    emp.name,
                    style: TextHelper.h1(context),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    'Employee ID: #${emp.id}',
                    style: TextHelper.captionMedium(context).copyWith(
                      color: AppColors.textSecondaryLight,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 4.h),
            _DetailCard(
              title: 'Contact Information',
              children: [
                _DetailRow(
                  icon: Icons.email_outlined,
                  label: 'Email',
                  value: emp.email,
                ),
                const Divider(),
                _DetailRow(
                  icon: Icons.phone_outlined,
                  label: 'Mobile',
                  value: emp.mobile,
                ),
              ],
            ),
            SizedBox(height: 2.h),
            _DetailCard(
              title: 'Location Details',
              children: [
                _DetailRow(
                  icon: Icons.public_outlined,
                  label: 'Country',
                  value: emp.country,
                ),
                const Divider(),
                _DetailRow(
                  icon: Icons.map_outlined,
                  label: 'State',
                  value: emp.state,
                ),
                const Divider(),
                _DetailRow(
                  icon: Icons.location_city_outlined,
                  label: 'District',
                  value: emp.district,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _DetailCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextHelper.h3(context).copyWith(
                color: AppColors.primary,
              ),
            ),
            SizedBox(height: 2.h),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary, size: 20),
          SizedBox(width: 3.w),
          Text(
            label,
            style: TextHelper.bodyMedium(context).copyWith(
              color: AppColors.textSecondaryLight,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: TextHelper.bodyMedium(context).copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
