// lib/screens/Auth/forgot_password_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../controller/auth/auth_controller.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';
import '../../utils/validators.dart';
import '../../widgets/textfields/custom_textfield.dart';

class ForgotPasswordScreen extends GetView<AuthController> {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reset Password'),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 3.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(
                Icons.mark_email_unread_outlined,
                size: 40.sp,
                color: AppColors.primary,
              ),
              SizedBox(height: 2.h),
              Text(
                'Forgot Your Password?',
                textAlign: TextAlign.center,
                style: TextHelper.h2(context),
              ),
              SizedBox(height: 1.h),
              Text(
                'Enter your registered email address and we will send you a password reset link.',
                textAlign: TextAlign.center,
                style: TextHelper.bodyMedium(context).copyWith(
                  color: AppColors.textSecondaryLight,
                ),
              ),
              SizedBox(height: 4.h),
              CustomTextField(
                controller: controller.emailController,
                label: 'Email Address',
                hint: 'enter your registered email',
                prefixIcon: Icons.email_outlined,
                keyboardType: TextInputType.emailAddress,
                validator: Validators.email,
              ),
              SizedBox(height: 2.h),
              Obx(
                () => ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: controller.isLoading.value
                      ? null
                      : controller.sendPasswordResetEmail,
                  child: controller.isLoading.value
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : Text(
                          'Send Reset Link',
                          style: TextHelper.buttonText(context).copyWith(
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
