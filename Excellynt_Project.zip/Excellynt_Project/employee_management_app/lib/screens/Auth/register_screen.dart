// lib/screens/Auth/register_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../controller/auth/auth_controller.dart';
import '../../routes/routes.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';
import '../../utils/validators.dart';
import '../../widgets/textfields/custom_textfield.dart';

class RegisterScreen extends GetView<AuthController> {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Account'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
          child: Form(
            key: controller.registerFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Join Us',
                  style: TextHelper.h1(context),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  'Fill in your details to create an account',
                  style: TextHelper.bodyMedium(context).copyWith(
                    color: AppColors.textSecondaryLight,
                  ),
                ),
                SizedBox(height: 3.h),
                CustomTextField(
                  controller: controller.nameController,
                  label: 'Full Name',
                  hint: 'enter your full name',
                  prefixIcon: Icons.person_outline,
                  validator: (v) => Validators.required(v, field: 'Full Name'),
                ),
                CustomTextField(
                  controller: controller.emailController,
                  label: 'Email Address',
                  hint: 'enter your email',
                  prefixIcon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                  validator: Validators.email,
                ),
                Obx(
                  () => CustomTextField(
                    controller: controller.passwordController,
                    label: 'Password',
                    hint: 'enter password (min 6 chars)',
                    prefixIcon: Icons.lock_outline,
                    obscureText: !controller.isPasswordVisible.value,
                    validator: Validators.password,
                    suffixIcon: IconButton(
                      icon: Icon(
                        controller.isPasswordVisible.value
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: AppColors.textSecondaryLight,
                      ),
                      onPressed: controller.togglePasswordVisibility,
                    ),
                  ),
                ),
                Obx(
                  () => CustomTextField(
                    controller: controller.confirmPasswordController,
                    label: 'Confirm Password',
                    hint: 're-enter password',
                    prefixIcon: Icons.lock_outline,
                    obscureText: !controller.isPasswordVisible.value,
                    validator: (v) => Validators.confirmPassword(
                      v,
                      controller.passwordController.text,
                    ),
                  ),
                ),
                SizedBox(height: 2.h),
                Obx(
                  () => ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: controller.isLoading.value
                        ? null
                        : controller.registerWithEmail,
                    child: controller.isLoading.value
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : Text(
                            'Register',
                            style: TextHelper.buttonText(context).copyWith(
                              color: Colors.white,
                            ),
                          ),
                  ),
                ),
                SizedBox(height: 3.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Already have an account? ',
                      style: TextHelper.bodyMedium(context),
                    ),
                    GestureDetector(
                      onTap: () => Get.offNamed(Routes.login),
                      child: Text(
                        'Sign In',
                        style: TextHelper.bodyMedium(context).copyWith(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
