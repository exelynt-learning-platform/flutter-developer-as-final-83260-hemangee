// lib/widgets/dialogs/confirm_dialog.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../utils/app_colors.dart';
import '../../utils/text_styles.dart';

class ConfirmDialog extends StatelessWidget {
  final String title;
  final String message;
  final String confirmText;
  final Color confirmColor;
  final VoidCallback onConfirm;

  const ConfirmDialog({
    super.key,
    required this.title,
    required this.message,
    this.confirmText = 'Confirm',
    this.confirmColor = AppColors.error,
    required this.onConfirm,
  });

  static Future<bool?> show({
    required String title,
    required String message,
    String confirmText = 'Confirm',
    Color confirmColor = AppColors.error,
    required VoidCallback onConfirm,
  }) {
    return Get.dialog<bool>(
      ConfirmDialog(
        title: title,
        message: message,
        confirmText: confirmText,
        confirmColor: confirmColor,
        onConfirm: onConfirm,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(
        title,
        style: TextHelper.h3(context),
      ),
      content: Text(
        message,
        style: TextHelper.bodyMedium(context),
      ),
      actions: [
        TextButton(
          onPressed: () => Get.back(result: false),
          child: Text(
            'Cancel',
            style: TextHelper.buttonText(context).copyWith(
              color: AppColors.textSecondaryLight,
            ),
          ),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: confirmColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          onPressed: () {
            Get.back(result: true);
            onConfirm();
          },
          child: Text(
            confirmText,
            style: TextHelper.buttonText(context).copyWith(
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
