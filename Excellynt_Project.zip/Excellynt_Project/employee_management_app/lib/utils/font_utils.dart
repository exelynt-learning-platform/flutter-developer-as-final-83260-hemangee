// lib/utils/font_utils.dart
class FontUtils {
  FontUtils._();
  static String getFontFamily() => 'Poppins';
}
