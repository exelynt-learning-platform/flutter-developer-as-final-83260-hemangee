// lib/utils/theme_config.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'app_colors.dart';
import 'font_utils.dart';

class ThemeConfig {
  static String _font() => FontUtils.getFontFamily();

  static ThemeData lightTheme() {
    final cs = const ColorScheme.light(
      primary: AppColors.primary,
      primaryContainer: AppColors.primaryExtraLight,
      secondary: AppColors.accent,
      secondaryContainer: AppColors.accentLight,
      surface: AppColors.surface,
      onSurface: AppColors.textDark,
      onSurfaceVariant: AppColors.textMedium,
      error: AppColors.error,
      shadow: AppColors.border,
    );
    return _build(cs);
  }

  static ThemeData darkTheme() {
    final cs = const ColorScheme.dark(
      primary: AppColors.primaryLight,
      primaryContainer: AppColors.primaryDark,
      secondary: AppColors.accent,
      secondaryContainer: AppColors.primaryDark,
      surface: AppColors.surfaceDark,
      onSurface: AppColors.textWhite,
      onSurfaceVariant: AppColors.textHint,
      error: AppColors.error,
      shadow: Color(0xFF0D1B2E),
    );
    return _build(cs);
  }

  static ThemeData _build(ColorScheme cs) {
    final tt = _textTheme(cs);
    return ThemeData(
      fontFamily: _font(),
      brightness: cs.brightness,
      colorScheme: cs,
      primaryColor: cs.primary,
      scaffoldBackgroundColor: cs.brightness == Brightness.light ? AppColors.bgLight : AppColors.bgDark,
      useMaterial3: true,
      textTheme: tt,
      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: cs.brightness == Brightness.light ? AppColors.surface : AppColors.surfaceDark,
        foregroundColor: cs.onSurface,
        centerTitle: false,
        iconTheme: IconThemeData(size: 16.sp, color: cs.onSurface),
        actionsIconTheme: IconThemeData(size: 16.sp, color: cs.onSurface),
        titleTextStyle: TextStyle(fontFamily: _font(), fontSize: 16.sp, fontWeight: FontWeight.w600, color: cs.onSurface),
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: cs.brightness == Brightness.light ? Brightness.dark : Brightness.light,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: cs.brightness == Brightness.light ? AppColors.card : AppColors.cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: cs.brightness == Brightness.light ? AppColors.border : const Color(0xFF1E3A5C), width: 1),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: cs.brightness == Brightness.light ? AppColors.bgLight : AppColors.primaryDark,
        floatingLabelBehavior: FloatingLabelBehavior.never,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: cs.primary, width: 2)),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.error)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.error, width: 2)),
        hintStyle: TextStyle(fontFamily: _font(), fontSize: 12.sp, color: AppColors.textHint),
        labelStyle: TextStyle(fontFamily: _font(), fontSize: 12.sp, color: AppColors.textLight),
        errorStyle: TextStyle(fontFamily: _font(), fontSize: 10.sp, color: AppColors.error),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: cs.primary,
          foregroundColor: Colors.white,
          minimumSize: Size(double.infinity, 52),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: TextStyle(fontFamily: _font(), fontSize: 14.sp, fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: cs.primary,
          minimumSize: Size(double.infinity, 52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          side: BorderSide(color: cs.primary, width: 1.5),
          textStyle: TextStyle(fontFamily: _font(), fontSize: 14.sp, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: cs.primary,
          textStyle: TextStyle(fontFamily: _font(), fontSize: 12.sp, fontWeight: FontWeight.w600),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: cs.primaryContainer,
        selectedColor: cs.primary,
        labelStyle: TextStyle(fontFamily: _font(), fontSize: 10.sp),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(color: AppColors.divider, thickness: 1),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: cs.primary,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: cs.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        titleTextStyle: TextStyle(fontFamily: _font(), fontSize: 16.sp, fontWeight: FontWeight.w700, color: cs.onSurface),
        contentTextStyle: TextStyle(fontFamily: _font(), fontSize: 12.sp, color: cs.onSurfaceVariant),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.textDark,
        contentTextStyle: TextStyle(fontFamily: _font(), color: Colors.white, fontSize: 12.sp),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: cs.surface,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      ),
      listTileTheme: ListTileThemeData(iconColor: cs.primary, tileColor: Colors.transparent),
    );
  }

  static TextTheme _textTheme(ColorScheme cs) {
    final f = _font();
    final c = cs.onSurface;
    return TextTheme(
      displayLarge:  TextStyle(fontFamily: f, fontSize: 28.sp, color: c, fontWeight: FontWeight.w700),
      displayMedium: TextStyle(fontFamily: f, fontSize: 24.sp, color: c, fontWeight: FontWeight.w700),
      displaySmall:  TextStyle(fontFamily: f, fontSize: 22.sp, color: c, fontWeight: FontWeight.w600),
      headlineLarge: TextStyle(fontFamily: f, fontSize: 20.sp, color: c, fontWeight: FontWeight.w600),
      headlineMedium:TextStyle(fontFamily: f, fontSize: 18.sp, color: c, fontWeight: FontWeight.w600),
      headlineSmall: TextStyle(fontFamily: f, fontSize: 16.sp, color: c, fontWeight: FontWeight.w600),
      titleLarge:    TextStyle(fontFamily: f, fontSize: 15.sp, color: c, fontWeight: FontWeight.w600),
      titleMedium:   TextStyle(fontFamily: f, fontSize: 14.sp, color: c, fontWeight: FontWeight.w500),
      titleSmall:    TextStyle(fontFamily: f, fontSize: 13.sp, color: c, fontWeight: FontWeight.w500),
      bodyLarge:     TextStyle(fontFamily: f, fontSize: 13.sp, color: c, fontWeight: FontWeight.w400),
      bodyMedium:    TextStyle(fontFamily: f, fontSize: 12.sp, color: c, fontWeight: FontWeight.w400),
      bodySmall:     TextStyle(fontFamily: f, fontSize: 11.sp, color: c, fontWeight: FontWeight.w400),
      labelLarge:    TextStyle(fontFamily: f, fontSize: 12.sp, color: c, fontWeight: FontWeight.w600),
      labelMedium:   TextStyle(fontFamily: f, fontSize: 10.sp, color: c, fontWeight: FontWeight.w500),
      labelSmall:    TextStyle(fontFamily: f, fontSize: 9.sp,  color: c, fontWeight: FontWeight.w400),
    );
  }
}
