// lib/utils/validators.dart
class Validators {
  Validators._();

  static String? required(String? val, {String field = 'This field'}) {
    if (val == null || val.trim().isEmpty) return '$field is required';
    return null;
  }

  static String? email(String? val) {
    if (val == null || val.trim().isEmpty) return 'Email is required';
    final regex = RegExp(r'^[\w.+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$');
    if (!regex.hasMatch(val.trim())) return 'Enter a valid email address';
    return null;
  }

  static String? password(String? val) {
    if (val == null || val.trim().isEmpty) return 'Password is required';
    if (val.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  static String? confirmPassword(String? val, String original) {
    if (val == null || val.trim().isEmpty) return 'Please confirm your password';
    if (val != original) return 'Passwords do not match';
    return null;
  }

  static String? name(String? val) {
    if (val == null || val.trim().isEmpty) return 'Name is required';
    if (val.trim().length < 2) return 'Name must be at least 2 characters';
    return null;
  }

  static String? mobile(String? val) {
    if (val == null || val.trim().isEmpty) return 'Mobile number is required';
    final regex = RegExp(r'^\+?[0-9]{7,15}$');
    if (!regex.hasMatch(val.trim())) return 'Enter a valid mobile number';
    return null;
  }

  static String? phone(String? val) => mobile(val);

  static String? dropdown(String? val, {String field = 'This field'}) {
    if (val == null || val.isEmpty) return 'Please select $field';
    return null;
  }
}
