// lib/utils/text_styles.dart
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'font_utils.dart';

class TextHelper {
  TextHelper._();

  static String get _font => FontUtils.getFontFamily();

  static TextStyle size10(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 10.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size11(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 11.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size12(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 12.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size13(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 13.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size14(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 14.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size15(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 15.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size16(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 16.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size18(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 18.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size20(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 20.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size22(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 22.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle size24(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 24.sp, color: Theme.of(context).colorScheme.onSurface);

  static TextStyle h1(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 20.sp, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle h2(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 16.sp, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle h3(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 13.sp, fontWeight: FontWeight.w600, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle bodyMedium(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 11.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle captionMedium(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 10.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle captionSmall(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 9.sp, color: Theme.of(context).colorScheme.onSurface);
  static TextStyle buttonText(BuildContext context) => TextStyle(fontFamily: _font, fontSize: 12.sp, fontWeight: FontWeight.w600, color: Theme.of(context).colorScheme.onSurface);
}
