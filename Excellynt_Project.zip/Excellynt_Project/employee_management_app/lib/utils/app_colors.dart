// lib/utils/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Primary Brand – Deep Corporate Blue
  static const Color primary = Color(0xFF1A3C6E);
  static const Color primaryLight = Color(0xFF2A5BA8);
  static const Color primaryExtraLight = Color(0xFFE3ECFB);
  static const Color primaryDark = Color(0xFF0D2444);

  // Accent
  static const Color accent = Color(0xFF00A8E8);
  static const Color accentLight = Color(0xFFCCEEFB);

  // Backgrounds
  static const Color bgLight = Color(0xFFF5F7FA);
  static const Color bgDark = Color(0xFF0F1C30);

  // Surface
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceDark = Color(0xFF182A42);
  static const Color card = Color(0xFFFFFFFF);
  static const Color cardDark = Color(0xFF1E3452);

  // Text
  static const Color textDark = Color(0xFF0F1C2D);
  static const Color textMedium = Color(0xFF3D5168);
  static const Color textLight = Color(0xFF7E95AE);
  static const Color textSecondaryLight = Color(0xFF7E95AE);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textHint = Color(0xFFAEBFD0);

  // Status
  static const Color success = Color(0xFF1DB870);
  static const Color error = Color(0xFFE53E3E);
  static const Color warning = Color(0xFFF6AD55);
  static const Color info = Color(0xFF3182CE);

  // Borders & Dividers
  static const Color border = Color(0xFFDEE8F4);
  static const Color borderLight = Color(0xFFDEE8F4);
  static const Color divider = Color(0xFFEEF3F9);

  // Avatar background palette
  static const List<Color> avatarBg = [
    Color(0xFF4A6FA5),
    Color(0xFF1DB870),
    Color(0xFFF6AD55),
    Color(0xFF9B59B6),
    Color(0xFFE74C3C),
    Color(0xFF16A085),
  ];

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF1A3C6E), Color(0xFF2A5BA8)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient heroGradient = LinearGradient(
    colors: [Color(0xFF0D2444), Color(0xFF1A3C6E), Color(0xFF2A5BA8)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFF1A3C6E), Color(0xFF1D5099)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
