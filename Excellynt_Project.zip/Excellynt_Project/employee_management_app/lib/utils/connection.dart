// lib/utils/connection.dart
import 'package:connectivity_plus/connectivity_plus.dart';

class Connection {
  bool hasInternet = true;
  bool initValue = true;

  Stream<bool> get onChangeConnectivity =>
      Connectivity().onConnectivityChanged.map(
        (results) => results.any((r) => r != ConnectivityResult.none),
      );

  static Future<bool> checkInternet() async {
    final results = await Connectivity().checkConnectivity();
    return results.any((r) => r != ConnectivityResult.none);
  }
}
