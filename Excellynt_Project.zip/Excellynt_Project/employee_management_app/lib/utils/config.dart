// lib/utils/config.dart
class Config {
  Config._();

  static const String appName = 'EmpManager';
  static const String baseUrl =
      'https://669b3f09276e45187d34eb4e.mockapi.io/api/v1';

  // API Endpoints
  static const String employeeEndpoint = '/employee';
  static const String countryEndpoint = '/country';

  // Timeouts (seconds)
  static const int connectTimeout = 30;
  static const int receiveTimeout = 30;

  // Use mock auth when Firebase is not configured
  // Set to false after adding google-services.json / GoogleService-Info.plist
  static const bool useMockAuth = true;
}
