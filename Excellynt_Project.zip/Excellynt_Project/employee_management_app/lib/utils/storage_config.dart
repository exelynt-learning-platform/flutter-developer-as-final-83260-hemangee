// lib/utils/storage_config.dart
import 'package:get_storage/get_storage.dart';

class StorageConfig {
  StorageConfig._();

  static final _box = GetStorage();

  // Keys
  static const String _themeKey = 'isDarkMode';
  static const String _cachedEmployeesKey = 'cached_employees';
  static const String _userNameKey = 'user_name';
  static const String _userEmailKey = 'user_email';
  static const String _userPhotoKey = 'user_photo';
  static const String _userUidKey = 'user_uid';

  // Theme
  static bool get isDarkMode => _box.read<bool>(_themeKey) ?? false;
  static Future<void> setDarkMode(bool val) => _box.write(_themeKey, val);

  // User info
  static String? get userName => _box.read<String>(_userNameKey);
  static String? get userEmail => _box.read<String>(_userEmailKey);
  static String? get userPhoto => _box.read<String>(_userPhotoKey);
  static String? get userUid => _box.read<String>(_userUidKey);

  static Future<void> saveUser({
    required String uid,
    required String email,
    String? name,
    String? photo,
  }) async {
    await _box.write(_userUidKey, uid);
    await _box.write(_userEmailKey, email);
    await _box.write(_userNameKey, name ?? '');
    await _box.write(_userPhotoKey, photo ?? '');
  }

  static Future<void> clearUser() async {
    await _box.remove(_userUidKey);
    await _box.remove(_userEmailKey);
    await _box.remove(_userNameKey);
    await _box.remove(_userPhotoKey);
  }

  static Map<String, String>? get user {
    if (!isLoggedIn) return null;
    return {
      'uid': userUid ?? '',
      'email': userEmail ?? '',
      'name': userName ?? '',
      'photo': userPhoto ?? '',
    };
  }

  static bool get isLoggedIn => (userUid?.isNotEmpty ?? false);

  // Employee cache
  static List? get cachedEmployees => _box.read<List>(_cachedEmployeesKey);
  static Future<void> cacheEmployees(List data) => _box.write(_cachedEmployeesKey, data);
  static Future<void> clearEmployeeCache() => _box.remove(_cachedEmployeesKey);
}
