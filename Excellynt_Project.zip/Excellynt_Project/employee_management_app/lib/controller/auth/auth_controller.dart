// lib/controller/auth/auth_controller.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../routes/routes.dart';
import '../../utils/config.dart';
import '../../utils/storage_config.dart';
import '../../utils/validators.dart';
import '../../widgets/dialogs/toast_helper.dart';

class AuthController extends GetxController {
  // ─── Form Keys ──────────────────────────────────────────────────────────────
  final loginFormKey = GlobalKey<FormState>();
  final registerFormKey = GlobalKey<FormState>();
  final forgotPasswordFormKey = GlobalKey<FormState>();

  // ─── Text Controllers ────────────────────────────────────────────────────────
  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final confirmPasswordCtrl = TextEditingController();
  final forgotEmailCtrl = TextEditingController();

  // Observables for state
  final isLoading = false.obs;
  final isGoogleLoading = false.obs;
  final showPassword = false.obs;
  final showConfirmPassword = false.obs;

  // Firebase
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // Observables for user info
  final userName = ''.obs;
  final userEmail = ''.obs;
  final userPhoto = ''.obs;
  final isPasswordVisible = false.obs;

  TextEditingController get emailController => emailCtrl;
  TextEditingController get passwordController => passwordCtrl;
  TextEditingController get nameController => nameCtrl;
  TextEditingController get confirmPasswordController => confirmPasswordCtrl;

  @override
  void onInit() {
    super.onInit();
    _loadUserInfo();
  }

  void _loadUserInfo() {
    final user = StorageConfig.user;
    if (user != null) {
      userName.value = user['name'] ?? '';
      userEmail.value = user['email'] ?? '';
      userPhoto.value = user['photo'] ?? '';
    }
  }

  void checkAuthState() {
    if (StorageConfig.isLoggedIn) {
      _loadUserInfo();
      Get.offAllNamed(Routes.employeeList);
    } else {
      Get.offAllNamed(Routes.login);
    }
  }

  Future<void> loginWithEmail() => login();
  Future<void> registerWithEmail() => register();
  Future<void> sendPasswordResetEmail() => sendPasswordReset();

  @override
  void onClose() {
    nameCtrl.dispose();
    emailCtrl.dispose();
    passwordCtrl.dispose();
    confirmPasswordCtrl.dispose();
    forgotEmailCtrl.dispose();
    super.onClose();
  }

  void togglePasswordVisibility() {
    showPassword.toggle();
    isPasswordVisible.value = showPassword.value;
  }
  void toggleConfirmPasswordVisibility() => showConfirmPassword.toggle();

  // ─── Login ──────────────────────────────────────────────────────────────────
  Future<void> login() async {
    if (!loginFormKey.currentState!.validate()) return;
    isLoading.value = true;
    try {
      if (Config.useMockAuth) {
        await Future.delayed(const Duration(milliseconds: 800));
        await StorageConfig.saveUser(
          uid: 'mock_uid_${DateTime.now().millisecondsSinceEpoch}',
          email: emailCtrl.text.trim(),
          name: 'Demo User',
        );
        Get.offAllNamed(Routes.employeeList);
        return;
      }
      final cred = await _auth.signInWithEmailAndPassword(
        email: emailCtrl.text.trim(),
        password: passwordCtrl.text,
      );
      final user = cred.user!;
      await StorageConfig.saveUser(
        uid: user.uid,
        email: user.email ?? '',
        name: user.displayName,
        photo: user.photoURL,
      );
      Get.offAllNamed(Routes.employeeList);
    } on FirebaseAuthException catch (e) {
      ToastHelper.showError(_mapFirebaseError(e.code));
    } catch (e) {
      ToastHelper.showError('Login failed. Please try again.');
    } finally {
      isLoading.value = false;
    }
  }

  // ─── Register ───────────────────────────────────────────────────────────────
  Future<void> register() async {
    if (!registerFormKey.currentState!.validate()) return;
    isLoading.value = true;
    try {
      if (Config.useMockAuth) {
        await Future.delayed(const Duration(milliseconds: 800));
        Get.back();
        ToastHelper.showSuccess('Account created! Please login.');
        return;
      }
      final cred = await _auth.createUserWithEmailAndPassword(
        email: emailCtrl.text.trim(),
        password: passwordCtrl.text,
      );
      await cred.user?.updateDisplayName(nameCtrl.text.trim());
      await cred.user?.reload();
      Get.offAllNamed(Routes.login);
      ToastHelper.showSuccess('Account created! Please login.');
    } on FirebaseAuthException catch (e) {
      ToastHelper.showError(_mapFirebaseError(e.code));
    } catch (e) {
      ToastHelper.showError('Registration failed. Please try again.');
    } finally {
      isLoading.value = false;
    }
  }

  // ─── Google Sign In ─────────────────────────────────────────────────────────
  Future<void> signInWithGoogle() async {
    isGoogleLoading.value = true;
    try {
      if (Config.useMockAuth) {
        await Future.delayed(const Duration(milliseconds: 1000));
        await StorageConfig.saveUser(
          uid: 'google_mock_uid',
          email: 'demo@google.com',
          name: 'Google User',
          photo: 'https://i.pravatar.cc/150?img=3',
        );
        Get.offAllNamed(Routes.employeeList);
        return;
      }
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return; // cancelled
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final userCred = await _auth.signInWithCredential(credential);
      final user = userCred.user!;
      await StorageConfig.saveUser(
        uid: user.uid,
        email: user.email ?? '',
        name: user.displayName,
        photo: user.photoURL,
      );
      Get.offAllNamed(Routes.employeeList);
    } on FirebaseAuthException catch (e) {
      ToastHelper.showError(_mapFirebaseError(e.code));
    } catch (e) {
      ToastHelper.showError('Google sign-in failed. Please try again.');
    } finally {
      isGoogleLoading.value = false;
    }
  }

  // ─── Forgot Password ─────────────────────────────────────────────────────────
  Future<void> sendPasswordReset() async {
    if (!forgotPasswordFormKey.currentState!.validate()) return;
    isLoading.value = true;
    try {
      if (Config.useMockAuth) {
        await Future.delayed(const Duration(milliseconds: 800));
        ToastHelper.showSuccess('Password reset email sent!');
        Get.back();
        return;
      }
      await _auth.sendPasswordResetEmail(email: forgotEmailCtrl.text.trim());
      ToastHelper.showSuccess('Password reset email sent! Check your inbox.');
      Get.back();
    } on FirebaseAuthException catch (e) {
      ToastHelper.showError(_mapFirebaseError(e.code));
    } catch (e) {
      ToastHelper.showError('Failed to send reset email.');
    } finally {
      isLoading.value = false;
    }
  }

  // ─── Logout ──────────────────────────────────────────────────────────────────
  Future<void> logout() async {
    if (!Config.useMockAuth) {
      await _googleSignIn.signOut();
      await _auth.signOut();
    }
    await StorageConfig.clearUser();
    await StorageConfig.clearEmployeeCache();
    Get.offAllNamed(Routes.login);
  }

  // ─── Validators ──────────────────────────────────────────────────────────────
  String? validateEmail(String? v) => Validators.email(v);
  String? validatePassword(String? v) => Validators.password(v);
  String? validateName(String? v) => Validators.name(v);
  String? validateConfirmPassword(String? v) =>
      Validators.confirmPassword(v, passwordCtrl.text);

  // ─── Firebase Error Mapping ──────────────────────────────────────────────────
  String _mapFirebaseError(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found for this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'invalid-credential':
        return 'Invalid credentials. Please try again.';
      case 'email-already-in-use':
        return 'This email is already registered.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Please check your connection.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}
