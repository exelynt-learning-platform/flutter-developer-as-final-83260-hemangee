// lib/controller/employee/employee_model.dart
class EmployeeModel {
  final String id;
  final String name;
  final String email;
  final String mobile;
  final String country;
  final String state;
  final String district;
  final String? avatar;
  final String? createdAt;

  const EmployeeModel({
    required this.id,
    required this.name,
    required this.email,
    required this.mobile,
    required this.country,
    required this.state,
    required this.district,
    this.avatar,
    this.createdAt,
  });

  factory EmployeeModel.fromJson(Map<String, dynamic> json) => EmployeeModel(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        email: json['email']?.toString() ?? '',
        mobile: json['mobile']?.toString() ?? json['phone']?.toString() ?? '',
        country: json['country']?.toString() ?? '',
        state: json['state']?.toString() ?? '',
        district: json['district']?.toString() ?? '',
        avatar: json['avatar']?.toString() ?? json['image']?.toString(),
        createdAt: json['createdAt']?.toString(),
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'mobile': mobile,
        'country': country,
        'state': state,
        'district': district,
        if (avatar != null) 'avatar': avatar,
      };

  EmployeeModel copyWith({
    String? id,
    String? name,
    String? email,
    String? mobile,
    String? country,
    String? state,
    String? district,
    String? avatar,
    String? createdAt,
  }) =>
      EmployeeModel(
        id: id ?? this.id,
        name: name ?? this.name,
        email: email ?? this.email,
        mobile: mobile ?? this.mobile,
        country: country ?? this.country,
        state: state ?? this.state,
        district: district ?? this.district,
        avatar: avatar ?? this.avatar,
        createdAt: createdAt ?? this.createdAt,
      );

  @override
  bool operator ==(Object other) => other is EmployeeModel && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

class CountryModel {
  final String id;
  final String name;
  final List<String> states;

  const CountryModel({
    required this.id,
    required this.name,
    this.states = const [],
  });

  String get country => name;

  factory CountryModel.fromJson(Map<String, dynamic> json) => CountryModel(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? json['country']?.toString() ?? '',
        states: json['states'] != null
            ? List<String>.from(json['states'])
            : const ['State 1', 'State 2'],
      );

  @override
  String toString() => name;
}
