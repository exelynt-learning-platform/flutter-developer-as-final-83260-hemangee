// lib/controller/employee/employee_controller.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../api/api_client.dart';
import '../../api/api_exception.dart';
import '../../routes/routes.dart';
import '../../utils/config.dart';
import '../../utils/storage_config.dart';
import '../../utils/validators.dart';
import '../../widgets/dialogs/toast_helper.dart';
import 'employee_model.dart';

enum EmployeeViewState { idle, loading, success, error, empty }
enum FilterType { name, email, mobile, country }

class EmployeeController extends GetxController {
  final isLoading = false.obs;
  final isSubmitting = false.obs;
  final isDeleting = false.obs;
  final isGridView = false.obs;
  final isOffline = false.obs;
  final selectedFilterField = 'Name'.obs;
  final selectedState = Rxn<String>();
  final selectedDistrict = Rxn<String>();

  TextEditingController get nameController => nameCtrl;
  TextEditingController get emailController => emailCtrl;
  TextEditingController get mobileController => mobileCtrl;

  List<CountryModel> get countriesList => countries;
  List<String> get statesList {
    final c = countries.firstWhereOrNull((element) => element.country == selectedCountry.value);
    return c?.states ?? [];
  }
  List<String> get districtsList => [];

  void toggleViewMode() => isGridView.toggle();

  void onCountryChanged(String country) {
    selectedCountry.value = country;
    selectedState.value = null;
    selectedDistrict.value = null;
  }

  void onStateChanged(String state) {
    selectedState.value = state;
    selectedDistrict.value = null;
  }

  void loadEmployeeForEdit(EmployeeModel emp) {
    _populateForm(emp);
  }

  void clearForm() {
    _clearForm();
  }

  // ─── Data & Form State ────────────────────────────────────────────────────────
  final viewState = EmployeeViewState.idle.obs;
  final employees = <EmployeeModel>[].obs;
  final filteredEmployees = <EmployeeModel>[].obs;
  final countries = <CountryModel>[].obs;
  final selectedEmployee = Rxn<EmployeeModel>();

  final searchController = TextEditingController();
  final searchQuery = ''.obs;
  final activeFilter = FilterType.name.obs;

  final formKey = GlobalKey<FormState>();
  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final mobileCtrl = TextEditingController();
  final stateCtrl = TextEditingController();
  final districtCtrl = TextEditingController();
  final selectedCountry = Rxn<String>();

  final searchByIdCtrl = TextEditingController();
  final searchedEmployee = Rxn<EmployeeModel>();
  final searchByIdState = EmployeeViewState.idle.obs;


  @override
  void onInit() {
    super.onInit();
    fetchEmployees();
    fetchCountries();
    debounce(searchQuery, (_) => _applyFilter(), time: const Duration(milliseconds: 300));
  }

  @override
  void onClose() {
    searchController.dispose();
    nameCtrl.dispose();
    emailCtrl.dispose();
    mobileCtrl.dispose();
    stateCtrl.dispose();
    districtCtrl.dispose();
    searchByIdCtrl.dispose();
    super.onClose();
  }

  // ─── Fetch All Employees ──────────────────────────────────────────────────────
  Future<void> fetchEmployees({bool showLoading = true}) async {
    if (showLoading) viewState.value = EmployeeViewState.loading;
    try {
      // Load from cache first
      final cached = StorageConfig.cachedEmployees;
      if (cached != null && cached.isNotEmpty && showLoading) {
        employees.value = cached.map((e) => EmployeeModel.fromJson(Map<String, dynamic>.from(e))).toList();
        _applyFilter();
        viewState.value = EmployeeViewState.success;
      }

      // Fetch fresh data
      final data = await ApiClient.instance.getAPICall(url: Config.employeeEndpoint);
      if (data is List) {
        final list = data.map((e) => EmployeeModel.fromJson(Map<String, dynamic>.from(e))).toList();
        employees.value = list;
        await StorageConfig.cacheEmployees(data.cast<Map>());
        _applyFilter();
        viewState.value = list.isEmpty ? EmployeeViewState.empty : EmployeeViewState.success;
      }
    } on NoInternetException {
      if (employees.isEmpty) viewState.value = EmployeeViewState.error;
      ToastHelper.showError('No internet connection. Showing cached data.');
    } on ApiException catch (e) {
      viewState.value = EmployeeViewState.error;
      ToastHelper.showError(e.message);
    } catch (e) {
      viewState.value = EmployeeViewState.error;
      ToastHelper.showError('Failed to fetch employees.');
    }
  }

  // ─── Fetch Employee by ID ─────────────────────────────────────────────────────
  Future<void> fetchEmployeeById(String id) async {
    if (id.trim().isEmpty) {
      ToastHelper.showError('Please enter an employee ID.');
      return;
    }
    searchByIdState.value = EmployeeViewState.loading;
    searchedEmployee.value = null;
    try {
      final data = await ApiClient.instance.getAPICall(url: '${Config.employeeEndpoint}/$id');
      if (data is Map) {
        searchedEmployee.value = EmployeeModel.fromJson(Map<String, dynamic>.from(data));
        searchByIdState.value = EmployeeViewState.success;
      }
    } on ApiException catch (e) {
      searchByIdState.value = EmployeeViewState.empty;
      ToastHelper.showError(e.message);
    } catch (e) {
      searchByIdState.value = EmployeeViewState.error;
      ToastHelper.showError('Employee not found.');
    }
  }

  // ─── Fetch Countries ──────────────────────────────────────────────────────────
  Future<void> fetchCountries() async {
    try {
      final data = await ApiClient.instance.getAPICall(url: Config.countryEndpoint);
      if (data is List) {
        countries.value = data.map((e) => CountryModel.fromJson(Map<String, dynamic>.from(e))).toList();
      }
    } catch (_) {
      // fail silently; user can type manually
    }
  }

  // ─── Create Employee ──────────────────────────────────────────────────────────
  Future<void> createEmployee() async {
    if (!formKey.currentState!.validate()) return;
    if (selectedCountry.value == null) {
      ToastHelper.showError('Please select a country.');
      return;
    }
    isSubmitting.value = true;
    try {
      final body = EmployeeModel(
        id: '',
        name: nameCtrl.text.trim(),
        email: emailCtrl.text.trim(),
        mobile: mobileCtrl.text.trim(),
        country: selectedCountry.value!,
        state: stateCtrl.text.trim(),
        district: districtCtrl.text.trim(),
      ).toJson();
      final data = await ApiClient.instance.postAPICall(url: Config.employeeEndpoint, data: body);
      if (data is Map) {
        final newEmp = EmployeeModel.fromJson(Map<String, dynamic>.from(data));
        employees.insert(0, newEmp);
        _applyFilter();
        await _syncCache();
        ToastHelper.showSuccess('Employee added successfully!');
        Get.back();
      }
    } on ApiException catch (e) {
      ToastHelper.showError(e.message);
    } catch (e) {
      ToastHelper.showError('Failed to create employee.');
    } finally {
      isSubmitting.value = false;
    }
  }

  // ─── Update Employee ──────────────────────────────────────────────────────────
  Future<void> updateEmployee(String id) async {
    if (!formKey.currentState!.validate()) return;
    if (selectedCountry.value == null) {
      ToastHelper.showError('Please select a country.');
      return;
    }
    isSubmitting.value = true;
    try {
      final body = {
        'name': nameCtrl.text.trim(),
        'email': emailCtrl.text.trim(),
        'mobile': mobileCtrl.text.trim(),
        'country': selectedCountry.value!,
        'state': stateCtrl.text.trim(),
        'district': districtCtrl.text.trim(),
      };
      final data = await ApiClient.instance.putAPICall(url: '${Config.employeeEndpoint}/$id', data: body);
      if (data is Map) {
        final updated = EmployeeModel.fromJson(Map<String, dynamic>.from(data));
        final idx = employees.indexWhere((e) => e.id == id);
        if (idx != -1) employees[idx] = updated;
        if (selectedEmployee.value?.id == id) selectedEmployee.value = updated;
        _applyFilter();
        await _syncCache();
        ToastHelper.showSuccess('Employee updated successfully!');
        Get.back();
      }
    } on ApiException catch (e) {
      ToastHelper.showError(e.message);
    } catch (e) {
      ToastHelper.showError('Failed to update employee.');
    } finally {
      isSubmitting.value = false;
    }
  }

  // ─── Delete Employee ──────────────────────────────────────────────────────────
  Future<void> deleteEmployee(String id) async {
    isDeleting.value = true;
    try {
      await ApiClient.instance.deleteAPICall(url: '${Config.employeeEndpoint}/$id');
      employees.removeWhere((e) => e.id == id);
      _applyFilter();
      await _syncCache();
      ToastHelper.showSuccess('Employee deleted successfully!');
      if (Get.currentRoute == Routes.employeeDetail) Get.back();
    } on ApiException catch (e) {
      ToastHelper.showError(e.message);
    } catch (e) {
      ToastHelper.showError('Failed to delete employee.');
    } finally {
      isDeleting.value = false;
    }
  }

  // ─── View Employee Detail ─────────────────────────────────────────────────────
  void viewEmployee(EmployeeModel emp) {
    selectedEmployee.value = emp;
    Get.toNamed(Routes.employeeDetail);
  }

  // ─── Navigate to Edit ─────────────────────────────────────────────────────────
  void navigateToEdit(EmployeeModel emp) {
    selectedEmployee.value = emp;
    _populateForm(emp);
    Get.toNamed(Routes.editEmployee);
  }

  // ─── Navigate to Add ─────────────────────────────────────────────────────────
  void navigateToAdd() {
    _clearForm();
    Get.toNamed(Routes.addEmployee);
  }

  // ─── Filter & Search ─────────────────────────────────────────────────────────
  void onSearchChanged(String val) => searchQuery.value = val;

  void setFilter(FilterType type) {
    activeFilter.value = type;
    _applyFilter();
  }

  void _applyFilter() {
    final query = searchQuery.value.toLowerCase().trim();
    if (query.isEmpty) {
      filteredEmployees.value = List.from(employees);
      return;
    }
    filteredEmployees.value = employees.where((e) {
      switch (activeFilter.value) {
        case FilterType.name:
          return e.name.toLowerCase().contains(query);
        case FilterType.email:
          return e.email.toLowerCase().contains(query);
        case FilterType.mobile:
          return e.mobile.toLowerCase().contains(query);
        case FilterType.country:
          return e.country.toLowerCase().contains(query);
      }
    }).toList();
  }

  void clearSearch() {
    searchController.clear();
    searchQuery.value = '';
  }

  // ─── Form Helpers ─────────────────────────────────────────────────────────────
  void _populateForm(EmployeeModel emp) {
    nameCtrl.text = emp.name;
    emailCtrl.text = emp.email;
    mobileCtrl.text = emp.mobile;
    stateCtrl.text = emp.state;
    districtCtrl.text = emp.district;
    selectedCountry.value = emp.country.isNotEmpty ? emp.country : null;
  }

  void _clearForm() {
    nameCtrl.clear();
    emailCtrl.clear();
    mobileCtrl.clear();
    stateCtrl.clear();
    districtCtrl.clear();
    selectedCountry.value = null;
  }

  // ─── Validators ──────────────────────────────────────────────────────────────
  String? validateName(String? v) => Validators.name(v);
  String? validateEmail(String? v) => Validators.email(v);
  String? validateMobile(String? v) => Validators.mobile(v);
  String? validateRequired(String? v, String field) => Validators.required(v, field: field);

  // ─── Cache Sync ───────────────────────────────────────────────────────────────
  Future<void> _syncCache() async {
    final raw = employees.map((e) => e.toJson()).toList();
    await StorageConfig.cacheEmployees(raw);
  }
}
