// lib/controller/app_controller.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../utils/connection.dart';
import '../utils/storage_config.dart';

class AppController extends GetxController {
  final connection = Connection();
  late StreamSubscription<bool> _connectivitySub;

  final isDarkMode = false.obs;

  @override
  void onInit() {
    super.onInit();
    isDarkMode.value = StorageConfig.isDarkMode;
    _startConnectivityWatch();
  }

  void _startConnectivityWatch() {
    _connectivitySub = connection.onChangeConnectivity.listen((hasInternet) {
      connection.hasInternet = hasInternet;
    });
  }

  Future<void> toggleTheme() async {
    isDarkMode.toggle();
    Get.changeThemeMode(isDarkMode.value ? ThemeMode.dark : ThemeMode.light);
    await StorageConfig.setDarkMode(isDarkMode.value);
  }

  @override
  void onClose() {
    _connectivitySub.cancel();
    super.onClose();
  }
}
