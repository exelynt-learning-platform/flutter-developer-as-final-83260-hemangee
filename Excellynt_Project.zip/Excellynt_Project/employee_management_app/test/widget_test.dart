// test/widget_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:employee_management_app/utils/config.dart';

void main() {
  test('App configuration smoke test', () {
    expect(Config.appName, 'EmpManager');
    expect(Config.useMockAuth, isTrue);
  });
}
