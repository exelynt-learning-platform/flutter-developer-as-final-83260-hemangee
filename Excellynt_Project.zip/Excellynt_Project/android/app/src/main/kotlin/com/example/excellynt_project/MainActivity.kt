package com.example.excellynt_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
